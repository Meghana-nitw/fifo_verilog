`timescale 1ns / 1ps

module fifo_core #(
    parameter DATA_WIDTH = 8,
    parameter DEPTH = 16,
    parameter ADDR_WIDTH = 4 // $clog2(16) = 4
)(
    input wire                    clk,
    input wire                    rst_n,
    input wire                    wr_en,
    input wire                    rd_en,
    input wire [DATA_WIDTH-1:0]   data_in,
    output wire [DATA_WIDTH-1:0]  data_out, // Converted to wire for look-ahead assignment
    output wire                   full,
    output wire                   empty,
    output reg [ADDR_WIDTH:0]     count   // 5-bit register storing values from 0 up to 16
);

    // Internal Memory Array and Address Pointers
    reg [DATA_WIDTH-1:0] mem [0:DEPTH-1];
    reg [ADDR_WIDTH-1:0] wr_ptr;          
    reg [ADDR_WIDTH-1:0] rd_ptr;          

    // Continuous Status Flag Logic Assignments
    assign full  = (count == DEPTH);
    assign empty = (count == 0);    

    // Look-Ahead Read Assignment (Clamped to 0 during reset/empty states to prevent red lines)
    assign data_out = (!rst_n || empty) ? {DATA_WIDTH{1'b0}} : mem[rd_ptr];

    // Synchronous Pointers and Counter State Machine Loop
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wr_ptr   <= 0;
            rd_ptr   <= 0;
            count    <= 0;
        end else begin
            case ({wr_en && !full, rd_en && !empty})
                
                2'b10: begin // Write-Only Transaction Window
                    mem[wr_ptr] <= data_in;
                    wr_ptr      <= wr_ptr + 1'b1;
                    count       <= count + 1'b1;
                end
                
                2'b01: begin // Read-Only Transaction Window
                    rd_ptr      <= rd_ptr + 1'b1;
                    count       <= count - 1'b1;
                end
                
                2'b11: begin // Concurrent Read and Write Phase
                    mem[wr_ptr] <= data_in;
                    wr_ptr      <= wr_ptr + 1'b1;
                    rd_ptr      <= rd_ptr + 1'b1;
                    // Net item count remains perfectly unchanged
                end
                
                default: ; // Boundary-protective catch-all default branch
            endcase
        end
    end
endmodule
